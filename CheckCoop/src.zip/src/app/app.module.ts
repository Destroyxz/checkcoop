import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';




import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './shared/header/header.component';
import { FooterComponent } from './shared/footer/footer.component';
import { AuthInterceptor } from './interceptor/auth.interceptor';


import { LoginComponent } from './components/Login/login.component';
import { DashboardComponent } from './components/Dashboard/dashboard.component';
import { RouterModule } from '@angular/router';
import { routes } from './app.routes';
//import { AuthGuard } from './guards/auth.guard';

@NgModule({  
  declarations: [    
    LoginComponent,
    DashboardComponent,
  ],
  imports: [    
    BrowserModule,    
    ReactiveFormsModule,    
    HttpClientModule,
    AppRoutingModule,
    AppComponent,    
    HeaderComponent,    
    FooterComponent,    

  ],
  providers: [
    {provide: HTTP_INTERCEPTORS, useClass: AuthInterceptor, multi: true}
  ],
  bootstrap: [AppComponent],
})
export class AppModule {}