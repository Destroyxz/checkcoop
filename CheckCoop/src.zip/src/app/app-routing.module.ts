import { BrowserModule } from '@angular/platform-browser';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { LoginComponent } from './components/Login/login.component';
import { DashboardComponent } from './components/Dashboard/dashboard.component';
import { AuthGuard } from './guards/auth.guard';
import { AuthService } from './services/auth.service';
const routes: Routes = [
  { path: 'login', component: LoginComponent },
  { path: 'dasboard', component: DashboardComponent, canActivate: [AuthGuard]},
  { path: '',   redirectTo: '/dashboard', pathMatch: 'full' },
  { path: '**', redirectTo: '/dashboard' }
]

@NgModule({  
  imports: [
    BrowserModule,
    ReactiveFormsModule,
    HttpClientModule,
    RouterModule.forRoot(routes)],  
  providers: [
    AuthService,
    AuthGuard
  ],
  exports: [RouterModule]
})
export class AppRoutingModule {}